﻿Remove-Item C:\www\accountability\am\*
Remove-Item C:\www\accountability\pm\*