﻿####################################################################################################################
#                                                                                                                  #
# Set your time zone by adding or removing the '#'. This will default to whichever is the last one missing an '#'. #
#                                                                                                                  #
####################################################################################################################

[System.TimeZoneInfo]::ConvertTimeBySystemTimeZoneId((Get-Date), 'Alaskan Standard Time').ToString('dd MMM yyyy') | Out-File C:\www\accountability\Accountability-Report.txt
#[System.TimeZoneInfo]::ConvertTimeBySystemTimeZoneId((Get-Date), 'Pacific Standard Time').ToString('dd MMM yyyy') | Out-File C:\www\accountability\Accountability-Report.txt
#[System.TimeZoneInfo]::ConvertTimeBySystemTimeZoneId((Get-Date), 'Mountain Standard Time').ToString('dd MMM yyyy') | Out-File C:\www\accountability\Accountability-Report.txt
#[System.TimeZoneInfo]::ConvertTimeBySystemTimeZoneId((Get-Date), 'Central Standard Time').ToString('dd MMM yyyy') | Out-File C:\www\accountability\Accountability-Report.txt
#[System.TimeZoneInfo]::ConvertTimeBySystemTimeZoneId((Get-Date), 'Eastern Standard Time').ToString('dd MMM yyyy') | Out-File C:\www\accountability\Accountability-Report.txt

####################################################################################################################
#                                                                                                                  #
# Adding accountability details in this section.                                                                   #
#                                                                                                                  #
####################################################################################################################

# Line Break for formatting.
Add-Content C:\www\accountability\Accountability-Report.txt ""

# Checking for morning accountability.
Add-Content C:\www\accountability\Accountability-Report.txt "People who have checked in this morning:"
Add-Content C:\www\accountability\Accountability-Report.txt ""
Get-ChildItem C:\www\accountability\am | Select-Object Name | Format-Table -HideTableHeaders | Out-File -FilePath C:\www\accountability\compare\am.txt
(Get-Content C:\www\accountability\compare\am.txt) | Where-Object{$_.trim() -ne ""} | Out-File C:\www\accountability\compare\am.txt -Force
Get-Content C:\www\accountability\compare\am.txt | Out-File C:\www\accountability\Accountability-Report.txt -Append
Get-Content C:\www\accountability\compare\am.txt | Out-File C:\www\accountability\docs\am-here.txt

# Line Break for formatting.
Add-Content C:\www\accountability\Accountability-Report.txt ""

# Checking for missing morning accountability.
Add-Content C:\www\accountability\Accountability-Report.txt "People who need to check in this morning:"
Add-Content C:\www\accountability\Accountability-Report.txt ""
Get-ChildItem C:\www\accountability\am | Select-Object Name | Format-Table -HideTableHeaders | Out-File -FilePath C:\www\accountability\compare\am.txt -Force
Get-ChildItem C:\www\accountability\names | Select-Object Name | Format-Table -HideTableHeaders | Out-File -FilePath C:\www\accountability\compare\total.txt -Force
(Get-Content C:\www\accountability\compare\total.txt) | Where-Object{$_.trim() -ne ""} | Out-File C:\www\accountability\compare\total.txt -Force
(Get-Content C:\www\accountability\compare\am.txt) | Where-Object{$_.trim() -ne ""} | Out-File C:\www\accountability\compare\am.txt -Force

$namespm=(Get-Content C:\www\accountability\compare\total.txt)
foreach ($namepm in $namespm)
    {
        $test=Test-Path -Path C:\www\accountability\am\$namepm
        if ($test -eq $false) 
            {
                Add-Content C:\www\accountability\Accountability-Report.txt $namepm
                Add-Content C:\www\accountability\docs\am-missing.txt $namepm
            }
    }

# Line Break for formatting.
Add-Content C:\www\accountability\Accountability-Report.txt ""

# Checking for evening accountability.
Add-Content C:\www\accountability\Accountability-Report.txt "People who have checked in this evening:"
Add-Content C:\www\accountability\Accountability-Report.txt ""
Get-ChildItem C:\www\accountability\pm | Select-Object Name | Format-Table -HideTableHeaders | Out-File -FilePath C:\www\accountability\compare\pm.txt
(Get-Content C:\www\accountability\compare\pm.txt) | Where-Object{$_.trim() -ne ""} | Out-File C:\www\accountability\compare\pm.txt -Force
Get-Content C:\www\accountability\compare\pm.txt | Out-File C:\www\accountability\Accountability-Report.txt -Append
Get-Content C:\www\accountability\compare\pm.txt | Out-File C:\www\accountability\docs\pm-here.txt

# Line Break for formatting.
Add-Content C:\www\accountability\Accountability-Report.txt ""

# Checking for missing evening accountability.
Add-Content C:\www\accountability\Accountability-Report.txt "People who need to check in this evening:"
Add-Content C:\www\accountability\Accountability-Report.txt ""
Get-ChildItem C:\www\accountability\names | Select-Object Name | Format-Table -HideTableHeaders | Out-File -FilePath C:\www\accountability\compare\total.txt -Force
Get-ChildItem C:\www\accountability\pm | Select-Object Name | Format-Table -HideTableHeaders | Out-File -FilePath C:\www\accountability\compare\pm.txt -Force
(Get-Content C:\www\accountability\compare\total.txt) | Where-Object{$_.trim() -ne ""} | Out-File C:\www\accountability\compare\total.txt -Force
(Get-Content C:\www\accountability\compare\pm.txt) | Where-Object{$_.trim() -ne ""} | Out-File C:\www\accountability\compare\pm.txt -Force

$namespm=(Get-Content C:\www\accountability\compare\total.txt)
foreach ($namepm in $namespm)
    {
        $test=Test-Path -Path C:\www\accountability\pm\$namepm
        if ($test -eq $false) 
            {
                Add-Content C:\www\accountability\Accountability-Report.txt $namepm
                Add-Content C:\www\accountability\docs\pm-missing.txt $namepm
            }
    }

####################################################################################################################
#                                                                                                                  #
# HTML Page Creation                                                                                               #
#                                                                                                                  #
####################################################################################################################

# Beginning of HTML Page
New-Item -Name Accountability.html C:\www\accountability\ -Force
Add-Content C:\www\accountability\Accountability.html '<html>'
Add-Content C:\www\accountability\Accountability.html '<head>'
Add-Content C:\www\accountability\Accountability.html '<title>'
Add-Content C:\www\accountability\Accountability.html 'Daily Accountability'
Add-Content C:\www\accountability\Accountability.html '</title>'
Add-Content C:\www\accountability\Accountability.html '<body bgcolor=”123456">'
Add-Content C:\www\accountability\Accountability.html '<style>'
Add-Content C:\www\accountability\Accountability.html 'table, th {'
Add-Content C:\www\accountability\Accountability.html 'border: 1px solid black; background-color:#E6E6FA; color:#000000;'
Add-Content C:\www\accountability\Accountability.html 'border-collapse: collapse;'
Add-Content C:\www\accountability\Accountability.html '}'
Add-Content C:\www\accountability\Accountability.html 'table, td {'
Add-Content C:\www\accountability\Accountability.html 'border: 1px solid black;'
Add-Content C:\www\accountability\Accountability.html 'border-collapse: collapse;'
Add-Content C:\www\accountability\Accountability.html '}'
Add-Content C:\www\accountability\Accountability.html '</style>'
Add-Content C:\www\accountability\Accountability.html '</head>'
Add-Content C:\www\accountability\Accountability.html '<body>'
Add-Content C:\www\accountability\Accountability.html '<h1>'
Add-Content C:\www\accountability\Accountability.html 'Daily Accountability'
Add-Content C:\www\accountability\Accountability.html '</h1>'
Add-Content C:\www\accountability\Accountability.html '<h4>'
Add-Content C:\www\accountability\Accountability.html 'Current Date: ' -NoNewline

####################################################################################################################
#                                                                                                                  #
# Set your time zone by adding or removing the '#'. This will default to whichever is the last one missing an '#'. #
#                                                                                                                  #
####################################################################################################################

[System.TimeZoneInfo]::ConvertTimeBySystemTimeZoneId((Get-Date), 'Alaskan Standard Time').ToString('dd MMM yyyy') | Out-File C:\www\accountability\Accountability.html -Append
#[System.TimeZoneInfo]::ConvertTimeBySystemTimeZoneId((Get-Date), 'Pacific Standard Time').ToString('dd MMM yyyy') | Out-File C:\www\accountability\Accountability.html -Append
#[System.TimeZoneInfo]::ConvertTimeBySystemTimeZoneId((Get-Date), 'Mountain Standard Time').ToString('dd MMM yyyy') | Out-File C:\www\accountability\Accountability.html -Append
#[System.TimeZoneInfo]::ConvertTimeBySystemTimeZoneId((Get-Date), 'Central Standard Time').ToString('dd MMM yyyy') | Out-File C:\www\accountability\Accountability.html -Append
#[System.TimeZoneInfo]::ConvertTimeBySystemTimeZoneId((Get-Date), 'Eastern Standard Time').ToString('dd MMM yyyy') | Out-File C:\www\accountability\Accountability.html -Append

####################################################################################################################
#                                                                                                                  #
# HTML Page Creation                                                                                               #
#                                                                                                                  #
####################################################################################################################

Add-Content C:\www\accountability\Accountability.html '</h4>'

# Table Creation
Add-Content C:\www\accountability\Accountability.html '<table style="width:100%">'
Add-Content C:\www\accountability\Accountability.html '<tr>'
Add-Content C:\www\accountability\Accountability.html '<th>'
Add-Content C:\www\accountability\Accountability.html 'Accounted For: Morning'
Add-Content C:\www\accountability\Accountability.html '</th>'
Add-Content C:\www\accountability\Accountability.html '<th>'
Add-Content C:\www\accountability\Accountability.html 'Missing For: Morning'
Add-Content C:\www\accountability\Accountability.html '</th>'
Add-Content C:\www\accountability\Accountability.html '<th>'
Add-Content C:\www\accountability\Accountability.html 'Accounted For: Evening'
Add-Content C:\www\accountability\Accountability.html '</th>'
Add-Content C:\www\accountability\Accountability.html '<th>'
Add-Content C:\www\accountability\Accountability.html 'Missing For: Evening'
Add-Content C:\www\accountability\Accountability.html '</th>'
Add-Content C:\www\accountability\Accountability.html '</tr>'
$amhere = (Get-Content C:\www\accountability\docs\am-here.txt)
$ammissing = (Get-Content C:\www\accountability\docs\am-missing.txt)
$pmhere = (Get-Content C:\www\accountability\docs\pm-here.txt)
$pmmissing = (Get-Content C:\www\accountability\docs\pm-missing.txt)
Add-Content C:\www\accountability\Accountability.html '<tr>'
Add-Content C:\www\accountability\Accountability.html '<td bgcolor="#8FBC8B">'
Add-Content C:\www\accountability\Accountability.html "<ol>"
foreach ($person in $amhere)
    {
        Add-Content C:\www\accountability\Accountability.html '<br>'
        Add-Content C:\www\accountability\Accountability.html $person
    }
Add-Content C:\www\accountability\Accountability.html '<br>'
Add-Content C:\www\accountability\Accountability.html '</ol>'
Add-Content C:\www\accountability\Accountability.html '</td>'
Add-Content C:\www\accountability\Accountability.html '<td bgcolor="#FFA07A">'
Add-Content C:\www\accountability\Accountability.html "<ol>"
foreach ($person in $ammissing)
    {
        Add-Content C:\www\accountability\Accountability.html '<br>'
        Add-Content C:\www\accountability\Accountability.html $person
    }
Add-Content C:\www\accountability\Accountability.html '<br>'
Add-Content C:\www\accountability\Accountability.html '</ol>'
Add-Content C:\www\accountability\Accountability.html '</td>'
Add-Content C:\www\accountability\Accountability.html '<td bgcolor="#8FBC8B">'
Add-Content C:\www\accountability\Accountability.html "<ol>"
foreach ($person in $pmhere)
    {
        Add-Content C:\www\accountability\Accountability.html '<br>'
        Add-Content C:\www\accountability\Accountability.html $person
    }
Add-Content C:\www\accountability\Accountability.html '<br>'
Add-Content C:\www\accountability\Accountability.html '</ol>'
Add-Content C:\www\accountability\Accountability.html '</td>'
Add-Content C:\www\accountability\Accountability.html '<td bgcolor="#FFA07A">'
Add-Content C:\www\accountability\Accountability.html "<ol>"
foreach ($person in $pmmissing)
    {
        Add-Content C:\www\accountability\Accountability.html '<br>'
        Add-Content C:\www\accountability\Accountability.html $person
    }
Add-Content C:\www\accountability\Accountability.html '<br>'
Add-Content C:\www\accountability\Accountability.html '</ol>'
Add-Content C:\www\accountability\Accountability.html '</td>'
Add-Content C:\www\accountability\Accountability.html '</tr>'

# End of HTML Page
Add-Content C:\www\accountability\Accountability.html '</table>'
Add-Content C:\www\accountability\Accountability.html '</body>'
Add-Content C:\www\accountability\Accountability.html '</html>'

####################################################################################################################
#                                                                                                                  #
# Move HTML File to Folder                                                                                         #
#                                                                                                                  #
####################################################################################################################

Copy-Item C:\www\accountability\Accountability.html C:\www\accountability\webpage\Accountability.html -Force

####################################################################################################################
#                                                                                                                  #
# Cleanup                                                                                                          #
#                                                                                                                  #
####################################################################################################################

Remove-Item C:\www\accountability\docs\*