﻿#---------------------------------------------------------[Initialisations]---------------------------------------------------------
# Init PowerShell Gui
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

#---------------------------------------------------------[Form]---------------------------------------------------------

[System.Windows.Forms.Application]::EnableVisualStyles()

$AccountabilityForm                = New-Object system.Windows.Forms.Form
$AccountabilityForm.ClientSize     = '420,250'
$AccountabilityForm.text           = "Accountability"
$AccountabilityForm.BackColor      = "#AFEEEE"
$AccountabilityForm.ForeColor      = "#000000"
$AccountabilityForm.TopMost        = $true
$AccountabilityForm.StartPosition  = "CenterScreen"

$Title                             = New-Object system.Windows.Forms.Label
$Title.text                        = "Check Another Person In"
$Title.AutoSize                    = $true
$Title.width                       = 25
$Title.height                      = 10
$Title.location                    = New-Object System.Drawing.Point(20,20)
$Title.Font                        = 'Microsoft Sans Serif,13'

$Description                       = New-Object system.Windows.Forms.Label
$Description.text                  = "Click on the 'Morning' or 'Evening' button to check that person in."
$Description.AutoSize              = $false
$Description.width                 = 450
$Description.height                = 50
$Description.location              = New-Object System.Drawing.Point(20,50)
$Description.Font                  = 'Microsoft Sans Serif,10'

$DropDownBox = New-Object System.Windows.Forms.ComboBox
$DropDownBox.text                  = "Please select a name from the list."
$DropDownBox.BackColor             = "#AFEEEE"
$DropDownBox.Location = New-Object System.Drawing.Size(20,100) 
$DropDownBox.DropDownHeight        = 100
$DropDownBox.DropDownWidth         = 250
$DropDownBox.Size = New-Object System.Drawing.Size(250,20) 
$DropDownBox.Font                   = 'Microsoft Sans Serif,10'
$DropDownBox.ForeColor              = "#000000"
$DropDownBox.Visible                = $true
$DropDownBox.DropDownStyle          = "DropDownList"
#$DropDownBox.add_SelectedIndexChanged = $DropDownBox.SelectedItem

$MorningButton                      = New-Object system.Windows.Forms.Button
$MorningButton.BackColor            = "#8FBC8B"
$MorningButton.text                 = "Morning"
$MorningButton.width                = 90
$MorningButton.height               = 30
$MorningButton.location             = New-Object System.Drawing.Point(300,100)
$MorningButton.Font                 = 'Microsoft Sans Serif,10'
$MorningButton.ForeColor            = "#000000"

$EveningButton                      = New-Object system.Windows.Forms.Button
$EveningButton.BackColor            = "#8FBC8B"
$EveningButton.text                 = "Evening"
$EveningButton.width                = 90
$EveningButton.height               = 30
$EveningButton.location             = New-Object System.Drawing.Point(300,150)
$EveningButton.Font                 = 'Microsoft Sans Serif,10'
$EveningButton.ForeColor            = "#000000"

$CancelButton                       = New-Object system.Windows.Forms.Button
$CancelButton.BackColor             = "#FFA07A"
$CancelButton.text                  = "Quit"
$CancelButton.width                 = 90
$CancelButton.height                = 30
$CancelButton.location              = New-Object System.Drawing.Point(300,200)
$CancelButton.Font                  = 'Microsoft Sans Serif,10'
$CancelButton.ForeColor             = "#000000"
$CancelButton.DialogResult          = [System.Windows.Forms.DialogResult]::Cancel
$AccountabilityForm.CancelButton    = $CancelButton

$AccountabilityForm.controls.AddRange(@($Title,$DropDownBox,$Description,$MorningButton,$EveningButton,$CancelButton))

#---------------------------------------------------------[Script]--------------------------------------------------------

(Get-Content C:\www\accountability\compare\total.txt) | Where-Object{$_.trim() -ne ""} | Out-File C:\www\accountability\compare\total.txt -Force
(Get-Content C:\www\accountability\compare\am.txt) | Where-Object{$_.trim() -ne ""} | Out-File C:\www\accountability\compare\am.txt -Force
(Get-Content C:\www\accountability\compare\pm.txt) | Where-Object{$_.trim() -ne ""} | Out-File C:\www\accountability\compare\pm.txt -Force

$names = Get-Content -Path 'C:\www\accountability\compare\total.txt'

foreach ($name in $names)
    {
        $DropDownBox.Items.Add($name)
        Clear-Host
    }

# NEED TO FIGURE OUT HOW TO ACTUALLY SELECT A NAME FROM THE LIST. IT WORKED EARLIER, BUT NOT NOW???

$MorningButton.add_Click({New-Item -Name $DropDownBox.SelectedItem -Path C:\www\accountability\am\ -Force})

$EveningButton.add_Click({New-Item -Name $DropDownBox.SelectedItem -Path C:\www\accountability\pm\ -Force})

[void]$AccountabilityForm.ShowDialog()